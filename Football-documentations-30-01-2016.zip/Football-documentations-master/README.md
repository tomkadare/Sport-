# Football-documentations

instructions:
 1. When you buy a new laptop or computer, or mobile phone start with this
 2. Search more code and download for your computer's safety protocoll.
 3. Write english txt files about football matches, just like the Hungarian and English (6-3) match in the Football World Championships in 1953.
 4. If you travel somewhere to live, make sure the Bible is on your machine, write Bible scripts every day.

So Write: 
 1. English Youtube Interviews (talks, conversations about famous or unknown people)
 1. Code scripts 
 2. Bible scripts
 3. Cookbook scripts
 4. Language Grammer scripts (English, French, Spanish)
 5. Type your favourite book
 6. Write a new Book just for fun
 7. Write artist competition text about photographs, ink and watercolor artworks. 
 8. Write New Business Plan
 9. Write about the day 10 short line
 10.Do an interview with someone En
